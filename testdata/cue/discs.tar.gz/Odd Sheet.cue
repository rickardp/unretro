﻿rem GENRE "Test Data"
REM COMMENT "FILE \"decoy.bin\" BINARY"

title "Odd  Sheet"
file "My Disc Image.bin" binary
	track 01 mode1/2352
		index 01 00:00:00  
  rem TRACK 09 AUDIO
	track 02 audio
		title "Second – track"
		index 01 00:00:30