REM unretro fixture: data track and two audio tracks in one file
CATALOG 0000000000000
PERFORMER "Fixture Generator"
TITLE "Mixed Mode"
FILE "mixed.bin" BINARY
  TRACK 01 MODE1/2352
    INDEX 01 00:00:00
  TRACK 02 AUDIO
    TITLE "Tone 441/882"
    PERFORMER "sox"
    FLAGS DCP
    INDEX 00 00:00:30
    INDEX 01 00:02:30
    INDEX 02 00:02:40
  TRACK 03 AUDIO
    TITLE "Tone 1470/2205"
    ISRC ABCDE0000001
    PREGAP 00:02:00
    INDEX 01 00:02:50
